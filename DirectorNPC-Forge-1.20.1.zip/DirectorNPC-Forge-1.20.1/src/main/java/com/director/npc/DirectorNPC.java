package com.director.npc;

import com.director.npc.network.ModNetwork;
import com.director.npc.registry.ModEntities;
import com.director.npc.registry.ModItems;
import com.director.npc.registry.ModCreativeTabs;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.common.MinecraftForge;

@Mod(DirectorNPC.MODID)
public class DirectorNPC {
    public static final String MODID = "director";

    public DirectorNPC() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        modBus.addListener(this::commonSetup);
        modBus.addListener(this::createAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }

    private void createAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.CUSTOM_NPC.get(), com.director.npc.entity.CustomNPCEntity.createAttributes().build());
    }
}

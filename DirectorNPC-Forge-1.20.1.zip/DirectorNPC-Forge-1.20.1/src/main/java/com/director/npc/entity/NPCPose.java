package com.director.npc.entity;

public enum NPCPose {
    STANDING, SITTING, LYING, STUMBLING;

    public static NPCPose fromId(int id) {
        NPCPose[] values = values();
        return id < 0 || id >= values.length ? STANDING : values[id];
    }
}

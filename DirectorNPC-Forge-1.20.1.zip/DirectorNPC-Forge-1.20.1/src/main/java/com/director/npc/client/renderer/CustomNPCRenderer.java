package com.director.npc.client.renderer;

import com.director.npc.entity.CustomNPCEntity;
import com.director.npc.entity.NPCPose;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CustomNPCRenderer extends MobRenderer<CustomNPCEntity, CustomNPCModel> {
    private final CustomNPCModel classicModel;
    private final CustomNPCModel slimModel;

    public CustomNPCRenderer(EntityRendererProvider.Context context) {
        super(context, new CustomNPCModel(context.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.classicModel = new CustomNPCModel(context.bakeLayer(ModelLayers.PLAYER), false);
        this.slimModel = new CustomNPCModel(context.bakeLayer(ModelLayers.PLAYER_SLIM), true);
    }

    @Override
    public ResourceLocation getTextureLocation(CustomNPCEntity entity) {
        return SkinManager.getTexture(entity.getSkin());
    }

    @Override
    protected void setupRotations(CustomNPCEntity entity, PoseStack poseStack, float ageInTicks,
                                  float rotationYaw, float partialTicks) {
        super.setupRotations(entity, poseStack, ageInTicks, rotationYaw, partialTicks);
        if (entity.getNPCPose() == NPCPose.SITTING) poseStack.translate(0.0D, -0.25D, 0.0D);
        if (entity.getNPCPose() == NPCPose.LYING) {
            poseStack.translate(0.0D, -0.55D, 0.0D);
            poseStack.mulPose(Axis.ZP.rotationDegrees(90.0F));
        }
    }

    @Override
    public CustomNPCModel getModel() {
        return super.getModel();
    }

    @Override
    public void render(CustomNPCEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       net.minecraft.client.renderer.MultiBufferSource buffer, int packedLight) {
        // O modelo é escolhido por entidade antes de renderizar.
        this.model = entity.isSlim() ? slimModel : classicModel;
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}

package com.director.npc.registry;

import com.director.npc.DirectorNPC;
import com.director.npc.item.*;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DirectorNPC.MODID);

    public static final RegistryObject<Item> SIT_SPAWNER = ITEMS.register("sit_spawner",
        () -> new SitSpawnerItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> STAND_SPAWNER = ITEMS.register("stand_spawner",
        () -> new StandSpawnerItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROUTINE_WAND = ITEMS.register("routine_wand",
        () -> new RoutineWandItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> NPC_REMOVER = ITEMS.register("npc_remover",
        () -> new NPCRemoverItem(new Item.Properties().stacksTo(1)));
}

package com.director.npc.client.renderer;

import com.director.npc.entity.CustomNPCEntity;
import com.director.npc.entity.NPCPose;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

public class CustomNPCModel extends PlayerModel<CustomNPCEntity> {
    public CustomNPCModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    @Override
    public void setupAnim(CustomNPCEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        if (entity.getNPCPose() == NPCPose.SITTING) {
            rightLeg.xRot = -1.35F;
            leftLeg.xRot = -1.35F;
            rightLeg.y = 12.0F;
            leftLeg.y = 12.0F;
            body.xRot = 0.08F;
            rightArm.xRot = -0.25F;
            leftArm.xRot = -0.25F;
        } else if (entity.getNPCPose() == NPCPose.LYING) {
            body.xRot = Mth.HALF_PI;
        }

        if (entity.isStumbling()) {
            float wave = Mth.sin(ageInTicks * 0.8F);
            body.zRot = wave * 0.18F;
            rightArm.xRot = -1.0F + wave * 0.25F;
            leftArm.xRot = -1.0F - wave * 0.25F;
            rightArm.zRot = -0.25F;
            leftArm.zRot = 0.25F;
            head.zRot = -wave * 0.08F;
        }
    }
}

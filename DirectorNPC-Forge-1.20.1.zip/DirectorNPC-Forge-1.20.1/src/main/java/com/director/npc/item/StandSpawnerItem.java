package com.director.npc.item;

import com.director.npc.entity.CustomNPCEntity;
import com.director.npc.entity.NPCPose;
import com.director.npc.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class StandSpawnerItem extends Item {
    public StandSpawnerItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        CustomNPCEntity npc = ModEntities.CUSTOM_NPC.get().create(level);
        if (npc == null) return InteractionResult.FAIL;
        float yaw = context.getPlayer() == null ? 0 : context.getPlayer().getYRot() + 180.0F;
        npc.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, yaw, 0);
        npc.setNPCPose(NPCPose.STANDING);
        level.addFreshEntity(npc);
        return InteractionResult.CONSUME;
    }
}

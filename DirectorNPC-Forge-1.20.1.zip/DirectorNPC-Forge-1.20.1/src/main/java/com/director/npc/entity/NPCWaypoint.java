package com.director.npc.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;

public record NPCWaypoint(BlockPos position, boolean sit, int waitTicks) {
    public NPCWaypoint {
        position = position.immutable();
        waitTicks = Math.max(0, Math.min(72000, waitTicks));
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("X", position.getX());
        tag.putInt("Y", position.getY());
        tag.putInt("Z", position.getZ());
        tag.putBoolean("Sit", sit);
        tag.putInt("WaitTicks", waitTicks);
        return tag;
    }

    public static NPCWaypoint load(CompoundTag tag) {
        return new NPCWaypoint(
            new BlockPos(tag.getInt("X"), tag.getInt("Y"), tag.getInt("Z")),
            tag.getBoolean("Sit"),
            tag.getInt("WaitTicks")
        );
    }
}

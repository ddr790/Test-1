package com.director.npc.item;

import com.director.npc.entity.CustomNPCEntity;
import com.director.npc.entity.NPCWaypoint;
import com.director.npc.menu.NPCConfigScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import java.util.UUID;

public class RoutineWandItem extends Item {
    public RoutineWandItem(Properties properties) { super(properties); }

    private void saveUUID(ItemStack stack, UUID uuid) { stack.getOrCreateTag().putUUID("SelectedNPC", uuid); }
    private UUID getUUID(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.hasUUID("SelectedNPC") ? tag.getUUID("SelectedNPC") : null;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof CustomNPCEntity npc)) return InteractionResult.PASS;
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        saveUUID(stack, npc.getUUID());
        player.displayClientMessage(Component.literal("NPC [" + npc.getName().getString() + "] selecionado"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.FAIL;
        UUID uuid = getUUID(context.getItemInHand());
        if (uuid == null) {
            player.displayClientMessage(Component.literal("Nenhum NPC selecionado!"), true);
            return InteractionResult.FAIL;
        }
        if (!(level instanceof ServerLevel server) || !(server.getEntity(uuid) instanceof CustomNPCEntity npc)) {
            player.displayClientMessage(Component.literal("NPC selecionado não está carregado neste mundo!"), true);
            return InteractionResult.FAIL;
        }
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        boolean sit = player.isShiftKeyDown();
        npc.addWaypoint(new NPCWaypoint(pos, sit, npc.getDefaultWaitTicks()));
        server.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + .5, pos.getY() + .5, pos.getZ() + .5,
            10, .25, .25, .25, 0.0);
        player.displayClientMessage(Component.literal(sit ? "Waypoint de sentar adicionado!" : "Waypoint adicionado!"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide && player.isShiftKeyDown()) {
            UUID uuid = getUUID(stack);
            if (uuid != null) openScreen(uuid);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @OnlyIn(Dist.CLIENT)
    private static void openScreen(UUID uuid) {
        net.minecraft.client.Minecraft.getInstance().setScreen(new NPCConfigScreen(uuid));
    }
}

package com.director.npc.client.renderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.loading.FMLPaths;
import java.io.InputStream;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SkinManager {
    private static final Map<String, ResourceLocation> CACHE = new ConcurrentHashMap<>();
    private static final ResourceLocation DEFAULT = new ResourceLocation("director", "textures/entity/default.png");
    private SkinManager() {}

    public static ResourceLocation getTexture(String skin) {
        if (skin == null || skin.isBlank() || skin.equals("default")) return DEFAULT;
        ResourceLocation cached = CACHE.get(skin);
        if (cached != null) return cached;
        // Carregamento local sob demanda; nomes são limitados a arquivos PNG dentro da pasta de skins.
        File dir = getSkinDirectory();
        File file = new File(dir, skin.endsWith(".png") ? skin : skin + ".png");
        try {
            String root = dir.getCanonicalPath() + File.separator;
            if (!file.getCanonicalPath().startsWith(root) || !file.isFile()) return DEFAULT;
            NativeImage image;
            try (InputStream input = java.nio.file.Files.newInputStream(file.toPath())) {
                image = NativeImage.read(input);
            }
            if (image.getWidth() != 64 || image.getHeight() != 64) {
                image.close();
                return DEFAULT;
            }
            DynamicTexture texture = new DynamicTexture(image);
            ResourceLocation location = Minecraft.getInstance().getTextureManager()
                .register("director_skin/" + safeName(skin), texture);
            CACHE.put(skin, location);
            return location;
        } catch (IOException | RuntimeException exception) {
            return DEFAULT;
        }
    }

    private static String safeName(String value) {
        return value.replaceAll("[^a-zA-Z0-9_.-]", "_");
    }

    public static File getSkinDirectory() {
        File dir = FMLPaths.CONFIGDIR.get().resolve("meumod").resolve("skins").toFile();
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }
}

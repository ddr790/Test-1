package com.director.npc.registry;

import com.director.npc.DirectorNPC;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DirectorNPC.MODID);

    public static final RegistryObject<CreativeModeTab> TOOLS = TABS.register("tools",
        () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.director.tools"))
            .icon(() -> new ItemStack(ModItems.ROUTINE_WAND.get()))
            .displayItems((parameters, output) -> {
                output.accept(ModItems.SIT_SPAWNER.get());
                output.accept(ModItems.STAND_SPAWNER.get());
                output.accept(ModItems.ROUTINE_WAND.get());
                output.accept(ModItems.NPC_REMOVER.get());
            }).build());
}

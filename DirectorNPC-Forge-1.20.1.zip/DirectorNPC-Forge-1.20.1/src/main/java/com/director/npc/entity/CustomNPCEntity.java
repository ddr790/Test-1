package com.director.npc.entity;

import com.director.npc.entity.goal.FollowRoutineGoal;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public class CustomNPCEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_POSE = SynchedEntityData.defineId(CustomNPCEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_STUMBLING = SynchedEntityData.defineId(CustomNPCEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_LOOK_PLAYER = SynchedEntityData.defineId(CustomNPCEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_REACT_COLLISION = SynchedEntityData.defineId(CustomNPCEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> DATA_SKIN = SynchedEntityData.defineId(CustomNPCEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> DATA_SLIM = SynchedEntityData.defineId(CustomNPCEntity.class, EntityDataSerializers.BOOLEAN);

    private final List<NPCWaypoint> waypoints = new ArrayList<>();
    private int stumbleTicks;
    private int collisionCooldown;
    private int currentWaypoint;
    private int routineWaitTicks;
    private int defaultWaitTicks = 40;
    private boolean routineEnabled;
    private boolean routineLoop = true;
    private boolean routineWaiting;

    public CustomNPCEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setInvulnerable(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 20.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.23D)
            .add(Attributes.FOLLOW_RANGE, 32.0D)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_POSE, NPCPose.STANDING.ordinal());
        entityData.define(DATA_STUMBLING, false);
        entityData.define(DATA_LOOK_PLAYER, false);
        entityData.define(DATA_REACT_COLLISION, true);
        entityData.define(DATA_SKIN, "default");
        entityData.define(DATA_SLIM, false);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new FollowRoutineGoal(this));
        goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    public NPCPose getNPCPose() { return NPCPose.fromId(entityData.get(DATA_POSE)); }

    public void setNPCPose(NPCPose pose) {
        entityData.set(DATA_POSE, pose.ordinal());
        if (pose == NPCPose.SITTING || pose == NPCPose.LYING) {
            getNavigation().stop();
            setDeltaMovement(Vec3.ZERO);
        }
    }

    public boolean isSitting() { return getNPCPose() == NPCPose.SITTING; }
    public boolean isStumbling() { return entityData.get(DATA_STUMBLING); }
    public String getSkin() { return entityData.get(DATA_SKIN); }
    public void setSkin(String skin) {
        if (skin != null && skin.length() <= 256) entityData.set(DATA_SKIN, skin);
    }
    public boolean isSlim() { return entityData.get(DATA_SLIM); }
    public void setSlim(boolean slim) { entityData.set(DATA_SLIM, slim); }
    public boolean shouldLookAtPlayer() { return entityData.get(DATA_LOOK_PLAYER); }
    public void setLookAtPlayer(boolean value) { entityData.set(DATA_LOOK_PLAYER, value); }
    public boolean canReactToCollision() { return entityData.get(DATA_REACT_COLLISION); }
    public void setReactToCollision(boolean value) { entityData.set(DATA_REACT_COLLISION, value); }

    public List<NPCWaypoint> getWaypoints() { return waypoints; }
    public int getCurrentWaypoint() { return currentWaypoint; }
    public void setCurrentWaypoint(int index) { currentWaypoint = Math.max(0, index); }
    public int getDefaultWaitTicks() { return defaultWaitTicks; }
    public void setDefaultWaitTicks(int ticks) { defaultWaitTicks = Math.max(0, Math.min(72000, ticks)); }
    public boolean isRoutineEnabled() { return routineEnabled; }
    public void setRoutineEnabled(boolean value) { routineEnabled = value; getNavigation().stop(); }
    public boolean isRoutineLoop() { return routineLoop; }
    public void setRoutineLoop(boolean value) { routineLoop = value; }
    public boolean isRoutineWaiting() { return routineWaiting; }
    public int getRoutineWaitTicks() { return routineWaitTicks; }

    public void setRoutineWaiting(int ticks) {
        routineWaitTicks = Math.max(0, ticks);
        routineWaiting = routineWaitTicks > 0;
    }

    public void addWaypoint(NPCWaypoint waypoint) {
        if (waypoints.size() < 256) waypoints.add(waypoint);
    }

    public void clearWaypoints() {
        waypoints.clear();
        currentWaypoint = 0;
        routineEnabled = false;
        routineWaiting = false;
        getNavigation().stop();
    }

    @Override
    public void push(Entity entity) {
        super.push(entity);
        if (level().isClientSide || !canReactToCollision() || entity == this || !entity.isAlive()) return;
        if (getNPCPose() == NPCPose.SITTING || getNPCPose() == NPCPose.LYING || isStumbling() || collisionCooldown > 0) return;
        if (!getBoundingBox().intersects(entity.getBoundingBox())) return;

        Vec3 away = position().subtract(entity.position());
        if (away.lengthSqr() < 1.0E-5) away = new Vec3(random.nextDouble() - 0.5, 0, random.nextDouble() - 0.5);
        away = away.normalize();
        setDeltaMovement(getDeltaMovement().add(away.x * 0.22D, 0.12D, away.z * 0.22D));
        hasImpulse = true;
        stumbleTicks = 18;
        collisionCooldown = 60;
        entityData.set(DATA_STUMBLING, true);
        entityData.set(DATA_POSE, NPCPose.STUMBLING.ordinal());
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (collisionCooldown > 0) collisionCooldown--;
        if (stumbleTicks > 0 && --stumbleTicks == 0) {
            entityData.set(DATA_STUMBLING, false);
            if (getNPCPose() == NPCPose.STUMBLING) setNPCPose(NPCPose.STANDING);
        }

        if (routineWaiting) {
            if (routineWaitTicks > 0) routineWaitTicks--;
            if (routineWaitTicks <= 0) {
                routineWaiting = false;
                if (isSitting()) setNPCPose(NPCPose.STANDING);
                currentWaypoint++;
            }
        }

        if (shouldLookAtPlayer()) {
            Player player = level().getNearestPlayer(this, 12.0D);
            if (player != null) getLookControl().setLookAt(player, 30.0F, 30.0F);
        }
    }

    public void setMainHand(ItemStack stack) { setItemSlot(EquipmentSlot.MAINHAND, stack); }
    public ItemStack getMainHand() { return getItemBySlot(EquipmentSlot.MAINHAND); }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    public void removeByDirector() {
        if (!level().isClientSide) discard();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("NPCPose", getNPCPose().ordinal());
        tag.putString("Skin", getSkin());
        tag.putBoolean("Slim", isSlim());
        tag.putBoolean("LookAtPlayer", shouldLookAtPlayer());
        tag.putBoolean("ReactToCollision", canReactToCollision());
        tag.putBoolean("RoutineEnabled", routineEnabled);
        tag.putBoolean("RoutineLoop", routineLoop);
        tag.putInt("CurrentWaypoint", currentWaypoint);
        tag.putInt("DefaultWaitTicks", defaultWaitTicks);
        ListTag list = new ListTag();
        for (NPCWaypoint waypoint : waypoints) list.add(waypoint.save());
        tag.put("Waypoints", list);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setNPCPose(NPCPose.fromId(tag.getInt("NPCPose")));
        setSkin(tag.contains("Skin") ? tag.getString("Skin") : "default");
        setSlim(tag.getBoolean("Slim"));
        setLookAtPlayer(tag.getBoolean("LookAtPlayer"));
        setReactToCollision(tag.contains("ReactToCollision") ? tag.getBoolean("ReactToCollision") : true);
        routineEnabled = tag.getBoolean("RoutineEnabled");
        routineLoop = !tag.contains("RoutineLoop") || tag.getBoolean("RoutineLoop");
        currentWaypoint = Math.max(0, tag.getInt("CurrentWaypoint"));
        defaultWaitTicks = Math.max(0, Math.min(72000, tag.getInt("DefaultWaitTicks")));
        waypoints.clear();
        ListTag list = tag.getList("Waypoints", 10);
        for (int i = 0; i < Math.min(list.size(), 256); i++) waypoints.add(NPCWaypoint.load(list.getCompound(i)));
        if (currentWaypoint >= waypoints.size()) currentWaypoint = 0;
    }
}

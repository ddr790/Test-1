package com.director.npc.network;

import com.director.npc.network.packet.NPCConfigPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation("director", "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;
    private ModNetwork() {}
    public static void register() {
        CHANNEL.registerMessage(id++, NPCConfigPacket.class, NPCConfigPacket::encode,
            NPCConfigPacket::decode, NPCConfigPacket::handle);
    }
}

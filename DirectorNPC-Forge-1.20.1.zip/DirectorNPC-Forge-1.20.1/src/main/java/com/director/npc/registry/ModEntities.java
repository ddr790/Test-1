package com.director.npc.registry;

import com.director.npc.DirectorNPC;
import com.director.npc.entity.CustomNPCEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DirectorNPC.MODID);

    public static final RegistryObject<EntityType<CustomNPCEntity>> CUSTOM_NPC =
        ENTITY_TYPES.register("custom_npc", () -> EntityType.Builder
            .of(CustomNPCEntity::new, MobCategory.MISC)
            .sized(0.6F, 1.8F)
            .clientTrackingRange(10)
            .updateInterval(2)
            .build("director:custom_npc"));
}

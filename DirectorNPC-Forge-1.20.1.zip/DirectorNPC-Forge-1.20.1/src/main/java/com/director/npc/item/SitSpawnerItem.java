package com.director.npc.item;

import com.director.npc.entity.CustomNPCEntity;
import com.director.npc.entity.NPCPose;
import com.director.npc.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class SitSpawnerItem extends Item {
    public SitSpawnerItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos clicked = context.getClickedPos();
        CustomNPCEntity npc = ModEntities.CUSTOM_NPC.get().create(level);
        if (npc == null) return InteractionResult.FAIL;
        npc.moveTo(clicked.getX() + 0.5D, clicked.getY() + 0.05D, clicked.getZ() + 0.5D,
            context.getPlayer() == null ? 0 : context.getPlayer().getYRot(), 0);
        npc.setNPCPose(NPCPose.SITTING);
        level.addFreshEntity(npc);
        return InteractionResult.CONSUME;
    }
}

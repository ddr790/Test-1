package com.director.npc.item;

import com.director.npc.entity.CustomNPCEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class NPCRemoverItem extends Item {
    public NPCRemoverItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof CustomNPCEntity npc)) return InteractionResult.PASS;
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        npc.removeByDirector();
        player.displayClientMessage(Component.literal("NPC removido!"), true);
        return InteractionResult.CONSUME;
    }
}

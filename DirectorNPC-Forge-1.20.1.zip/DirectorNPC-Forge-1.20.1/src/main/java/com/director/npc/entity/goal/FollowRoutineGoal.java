package com.director.npc.entity.goal;

import com.director.npc.entity.CustomNPCEntity;
import com.director.npc.entity.NPCPose;
import com.director.npc.entity.NPCWaypoint;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;
import java.util.List;

public class FollowRoutineGoal extends Goal {
    private final CustomNPCEntity npc;
    private static final double ARRIVAL_DISTANCE_SQR = 1.25D;

    public FollowRoutineGoal(CustomNPCEntity npc) {
        this.npc = npc;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        return npc.isRoutineEnabled() && !npc.getWaypoints().isEmpty()
            && !npc.isRoutineWaiting() && !npc.isStumbling()
            && npc.getNPCPose() != NPCPose.SITTING && npc.getNPCPose() != NPCPose.LYING;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() { moveToCurrent(); }

    @Override
    public void tick() {
        if (npc.isStumbling() || npc.isRoutineWaiting()) {
            npc.getNavigation().stop();
            return;
        }
        List<NPCWaypoint> points = npc.getWaypoints();
        int index = npc.getCurrentWaypoint();
        if (index >= points.size()) {
            finishRoutine();
            return;
        }
        NPCWaypoint point = points.get(index);
        BlockPos pos = point.position();
        double distance = npc.distanceToSqr(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
        if (distance <= ARRIVAL_DISTANCE_SQR) {
            arrive(point);
        } else if (npc.getNavigation().isDone()) {
            moveToCurrent();
        }
    }

    private void moveToCurrent() {
        List<NPCWaypoint> points = npc.getWaypoints();
        int index = npc.getCurrentWaypoint();
        if (index < 0 || index >= points.size()) return;
        BlockPos pos = points.get(index).position();
        npc.setNPCPose(NPCPose.STANDING);
        npc.getNavigation().moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, 1.0D);
    }

    private void arrive(NPCWaypoint point) {
        npc.getNavigation().stop();
        if (point.sit()) {
            npc.setNPCPose(NPCPose.SITTING);
            int wait = point.waitTicks() > 0 ? point.waitTicks() : npc.getDefaultWaitTicks();
            if (wait > 0) npc.setRoutineWaiting(wait);
            else npc.setCurrentWaypoint(npc.getCurrentWaypoint() + 1);
        } else {
            npc.setCurrentWaypoint(npc.getCurrentWaypoint() + 1);
        }
    }

    private void finishRoutine() {
        npc.getNavigation().stop();
        if (npc.isRoutineLoop()) npc.setCurrentWaypoint(0);
        else npc.setRoutineEnabled(false);
    }

    @Override
    public void stop() {
        if (!npc.isRoutineWaiting()) npc.getNavigation().stop();
    }
}

package com.director.npc.menu;

import com.director.npc.network.ModNetwork;
import com.director.npc.network.packet.NPCConfigPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.UUID;

public class NPCConfigScreen extends Screen {
    private final UUID npcUUID;
    private EditBox nameField;
    private EditBox skinField;
    private EditBox waitField;
    private boolean lookAtPlayer = true;
    private boolean reactCollision = true;
    private boolean loop = true;

    public NPCConfigScreen(UUID npcUUID) {
        super(Component.literal("NPC Director"));
        this.npcUUID = npcUUID;
    }

    @Override
    protected void init() {
        int x = width / 2 - 100;
        int y = 48;
        nameField = new EditBox(font, x, y, 200, 20, Component.literal("Nome"));
        nameField.setMaxLength(64);
        nameField.setValue("NPC");
        addRenderableWidget(nameField);

        skinField = new EditBox(font, x, y + 39, 200, 20, Component.literal("Skin"));
        skinField.setMaxLength(256);
        skinField.setValue("default");
        addRenderableWidget(skinField);

        waitField = new EditBox(font, x, y + 78, 200, 20, Component.literal("Espera em segundos"));
        waitField.setValue("2");
        addRenderableWidget(waitField);

        addRenderableWidget(toggleButton(x, y + 115, "Olhar para jogador", () -> lookAtPlayer = !lookAtPlayer, () -> lookAtPlayer));
        addRenderableWidget(toggleButton(x, y + 140, "Reagir a esbarrões", () -> reactCollision = !reactCollision, () -> reactCollision));
        addRenderableWidget(toggleButton(x, y + 165, "Loop da rotina", () -> loop = !loop, () -> loop));

        addRenderableWidget(Button.builder(Component.literal("SALVAR"), b -> save())
            .bounds(x, y + 202, 96, 20).build());
        addRenderableWidget(Button.builder(Component.literal("FECHAR"), b -> onClose())
            .bounds(x + 104, y + 202, 96, 20).build());
    }

    private Button toggleButton(int x, int y, String label, Runnable toggle, java.util.function.BooleanSupplier state) {
        Button button = Button.builder(toggleLabel(label, state.getAsBoolean()), b -> {
            toggle.run();
            b.setMessage(toggleLabel(label, state.getAsBoolean()));
        }).bounds(x, y, 200, 20).build();
        return button;
    }

    private Component toggleLabel(String label, boolean enabled) {
        return Component.literal(label + ": " + (enabled ? "SIM" : "NÃO"));
    }

    private void save() {
        int seconds;
        try { seconds = Integer.parseInt(waitField.getValue()); }
        catch (NumberFormatException exception) { seconds = 2; }
        seconds = Math.max(0, Math.min(3600, seconds));
        ModNetwork.CHANNEL.sendToServer(new NPCConfigPacket(npcUUID, nameField.getValue(),
            skinField.getValue(), lookAtPlayer, reactCollision, loop, seconds * 20));
        onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.drawCenteredString(font, "NPC DIRECTOR", width / 2, 20, 0xFFFFFF);
        graphics.drawString(font, "Nome:", width / 2 - 100, 36, 0xFFFFFF);
        graphics.drawString(font, "Skin (arquivo em config/meumod/skins):", width / 2 - 100, 75, 0xFFFFFF);
        graphics.drawString(font, "Tempo de espera (segundos):", width / 2 - 100, 114, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}

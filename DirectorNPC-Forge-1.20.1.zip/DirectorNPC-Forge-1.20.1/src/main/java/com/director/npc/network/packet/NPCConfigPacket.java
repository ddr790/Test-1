package com.director.npc.network.packet;

import com.director.npc.entity.CustomNPCEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;
import java.util.UUID;
import java.util.function.Supplier;

public class NPCConfigPacket {
    private final UUID npcUUID;
    private final String name;
    private final String skin;
    private final boolean lookAtPlayer;
    private final boolean reactCollision;
    private final boolean loop;
    private final int waitTicks;

    public NPCConfigPacket(UUID npcUUID, String name, String skin, boolean lookAtPlayer,
                           boolean reactCollision, boolean loop, int waitTicks) {
        this.npcUUID = npcUUID;
        this.name = name;
        this.skin = skin;
        this.lookAtPlayer = lookAtPlayer;
        this.reactCollision = reactCollision;
        this.loop = loop;
        this.waitTicks = waitTicks;
    }

    public static void encode(NPCConfigPacket msg, FriendlyByteBuf buf) {
        buf.writeUUID(msg.npcUUID);
        buf.writeUtf(msg.name, 64);
        buf.writeUtf(msg.skin, 256);
        buf.writeBoolean(msg.lookAtPlayer);
        buf.writeBoolean(msg.reactCollision);
        buf.writeBoolean(msg.loop);
        buf.writeVarInt(msg.waitTicks);
    }

    public static NPCConfigPacket decode(FriendlyByteBuf buf) {
        return new NPCConfigPacket(buf.readUUID(), buf.readUtf(64), buf.readUtf(256),
            buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readVarInt());
    }

    public static void handle(NPCConfigPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null || !player.getAbilities().mayBuild()) return;
            Entity entity = player.serverLevel().getEntity(msg.npcUUID);
            if (!(entity instanceof CustomNPCEntity npc)) return;
            if (player.distanceToSqr(npc) > 64.0D * 64.0D) return;
            String safeName = msg.name.trim();
            if (safeName.isEmpty()) safeName = "NPC";
            npc.setCustomName(Component.literal(safeName));
            npc.setCustomNameVisible(true);
            npc.setSkin(msg.skin);
            npc.setLookAtPlayer(msg.lookAtPlayer);
            npc.setReactToCollision(msg.reactCollision);
            npc.setRoutineLoop(msg.loop);
            npc.setDefaultWaitTicks(Math.max(0, Math.min(72000, msg.waitTicks)));
        });
        context.setPacketHandled(true);
    }
}

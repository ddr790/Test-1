# NPC Director Tools — Forge 1.20.1

Projeto-base para Minecraft Forge 1.20.1, Java 17, mappings oficiais.

## Requisitos
- JDK 17
- Gradle (use o wrapper do Forge MDK 1.20.1, recomendado) ou Gradle compatível com ForgeGradle 6
- Minecraft Forge 1.20.1-47.2.20

## Compilar
No diretório do projeto:
- Windows: `gradlew.bat build`
- Linux/macOS: `./gradlew build`

O JAR será gerado em `build/libs/`.

Para abrir no IntelliJ IDEA:
1. Abra a pasta do projeto como projeto Gradle.
2. Aguarde a importação.
3. Execute a configuração `runClient` criada pelo ForgeGradle.

## Conteúdo implementado
- Entidade `CustomNPCEntity` com NBT, dados sincronizados, equipamentos herdados de Mob, invulnerabilidade e reação básica a colisão.
- Goal de rotina com waypoints e espera sentada.
- Spawnadores sentado/parado, varinha e removedor.
- Aba criativa NPC Director Tools.
- SimpleChannel e tela de configuração.
- Renderer baseado em PlayerModel, modelos Slim/Classic e carregamento local de PNG 64x64.

## Skins
Coloque skins PNG 64x64 em:
`.minecraft/config/meumod/skins/`
Na GUI, informe o nome do arquivo (com ou sem `.png`). A skin padrão está em `assets/director/textures/entity/default.png`.

## Limitações desta versão
- A tela de configuração inicia com valores padrão; não há sincronização de leitura inicial dos valores existentes.
- A URL remota não está habilitada: apenas skins locais são carregadas. Isso evita downloads bloqueantes durante renderização.
- O posicionamento sentado é visual e genérico; não detecta automaticamente cadeira, escada ou altura ideal de cada superfície.
- A rotina usa navegação vanilla e waypoints alcançáveis.
- O comando administrativo e a exclusão pela GUI não foram incluídos; o item Removedor já remove NPCs.
- Recomenda-se testar em mundo de desenvolvimento antes de usar em servidor ou gravação longa.

## Observação
O projeto é uma base funcional para desenvolvimento/compilação, mas não foi executado em um ambiente Gradle nesta sessão. Faça o primeiro build e envie o log caso o ForgeGradle aponte incompatibilidade do ambiente.
